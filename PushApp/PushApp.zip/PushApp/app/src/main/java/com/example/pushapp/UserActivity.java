

package com.example.pushapp;

        import android.os.Bundle;
        import android.view.View;
        import android.view.Menu;

        import com.google.android.material.snackbar.Snackbar;
        import com.google.android.material.navigation.NavigationView;


        import androidx.navigation.NavController;
        import androidx.navigation.Navigation;
        import androidx.navigation.ui.AppBarConfiguration;
        import androidx.navigation.ui.NavigationUI;
        import androidx.drawerlayout.widget.DrawerLayout;
        import androidx.appcompat.app.AppCompatActivity;

        import com.example.pushapp.databinding.ActivityMainBinding;

        import android.content.Intent;
        import android.widget.TextView;

        import android.util.Log;
        import android.view.MenuItem;


public class UserActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;

    private static final String TAG = "UserActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarMain.toolbar);
        // 좌측 하단 메일 버튼
//        binding.appBarMain.fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.notifications, R.id.newsLetters, R.id.nav_slideshow)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                // 특정 버튼 클릭 이벤트 처리
                if (id == R.id.notifications) {
                    // API 호출 및 데이터 가져오기

                    return true;
                } else if  (id == R.id.newsLetters) {
                    // API 호출 및 데이터 가져오기

                    return true;
                }
                return false;
            }
        });

//        setProps();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    private void setProps() {
        // 아이디 설정
        // UserActivity에서 전달된 데이터 받기
//        Intent intent = getIntent();
//        String userId = intent.getStringExtra("user_id");
//
//        // 받아온 데이터를 사용하여 작업 수행
//        // 예시: 받아온 userId를 TextView에 설정
//        TextView textView = findViewById(R.id.user_id_section);
//
//        textView.setText( userId );


    }
}